package test3;

public class ThreadWordMainClass {
  public static void main(String args[]) {
      new ThreadFrame().setTitle("汉字打字练习");
   }
}
