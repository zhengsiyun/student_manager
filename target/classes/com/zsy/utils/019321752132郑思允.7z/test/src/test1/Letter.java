package test1;

public class Letter {
   char c ='\0';
   public void setChar(char c) {
      this.c = c;
   }
   public char getChar() {
      return c;
   }
}